# Promotion of O1v@10

<!-- adroit-chronology -->
Report generated (UTC): 2026-11-02T16:53:26.306502+00:00
Calculation started (UTC): 2026-11-02T16:53:26.298635+00:00
Calculation completed (UTC): 2026-11-02T16:53:26.302845+00:00
Conclusions apply to the recorded inputs and calculation date; later data or revisions require a new analysis.
<!-- /adroit-chronology -->

Parent: `parent`; no settled or reserved dollars recorded.

Promoted from the parent's result as read: SHA-256 `a330054e6641ef675b179a7cbe3685e28f1803f0475f7c8f0884b5dee93e07e4`.

| candidate | model | origin | verdict | study |
|---|---|---|---|---|

Without a study:

- O1v@10: isovector: no computable simplified completion produces it at tree level; the model builder can propose isovector completions

<!-- adroit-binding {"figures": {}, "result_sha256": "769d187f2b87d5bdc4523870ef61c667afe94f8d97de1f143d689b3c2f1b3e68"} -->
