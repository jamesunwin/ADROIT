# Promotion of O1v@40

<!-- adroit-chronology -->
Report generated (UTC): 2026-11-02T16:53:29.128699+00:00
Calculation started (UTC): 2026-11-02T16:53:29.122630+00:00
Calculation completed (UTC): 2026-11-02T16:53:29.125621+00:00
Conclusions apply to the recorded inputs and calculation date; later data or revisions require a new analysis.
<!-- /adroit-chronology -->

Parent: `parent`; no settled or reserved dollars recorded.

Promoted from the parent's result as read: SHA-256 `7afb217fc76f9744079e0ec52138c0f4d6dba4f37b19993b315a764652ee8c1c`.

| candidate | model | origin | verdict | study |
|---|---|---|---|---|

Without a study:

- O1v@40: isovector: no computable simplified completion produces it at tree level; the model builder can propose isovector completions

<!-- adroit-binding {"figures": {}, "result_sha256": "97b53d0b72fc87098e22eee8dd17be32fb043080cfa1f445e617e04348e0d49d"} -->
