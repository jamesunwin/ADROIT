# Promotion of scalar @ 20

<!-- adroit-chronology -->
Report generated (UTC): 2026-11-03T08:37:18.547794+00:00
Calculation started (UTC): 2026-11-03T08:36:59.656382+00:00
Calculation completed (UTC): 2026-11-03T08:37:18.534185+00:00
Conclusions apply to the recorded inputs and calculation date; later data or revisions require a new analysis.
<!-- /adroit-chronology -->

Parent: `signal`; no settled or reserved dollars recorded.

Promoted from the parent's result as read: SHA-256 `2a2ffabe96e57e1a995fd7645b7ee596040bb6ed2996bd97563f58dd568394cf`.

| candidate | model | origin | verdict | study |
|---|---|---|---|---|
| scalar @ 20 | vector_mediator_for_O1 | simplified completion | A VIABLE THERMAL EXPLANATION, PENDING A CALCULATION | `children/vector_mediator_for_O1_scalar_20` |
| scalar @ 20 | scalar_mediator_for_O1 | simplified completion | A VIABLE THERMAL EXPLANATION, PENDING A CALCULATION | `children/scalar_mediator_for_O1_scalar_20` |

<!-- adroit-binding {"figures": {}, "result_sha256": "f84d1da98b7c83267fd93136bb8a1abe50e3e7d794151b31d299c1887438d750"} -->
