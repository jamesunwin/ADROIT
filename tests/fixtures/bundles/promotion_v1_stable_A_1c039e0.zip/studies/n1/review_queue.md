# Requested-result review queue

<!-- adroit-chronology -->
Report generated (UTC): 2026-11-01T19:48:01.715603+00:00
Calculation date: unknown / not recorded
Conclusions apply to the recorded inputs and calculation date; later data or revisions require a new analysis.
<!-- /adroit-chronology -->

blocking requested conclusions first; descending distinct blocked physical points and selected studies; then source verification/missing input before new recasts; stable task ID tie-break. An unresolved check of an already excluded point does not overturn its exclusion.

| priority | task | record | blocked points | studies | action |
|---|---|---|---|---|---|
| 1 | missing_input | atlas-2004.14636-ww | 1 | 1 | Request the specific missing physical input from the researcher; do not fill it with a benchmark. |

- signal, candidate, `O1v@10` (pending): a relativistic completion (a mediator model with couplings to Standard Model particles), from which the mediator's production and decays follow
| 2 | missing_input | calore-2202.03076-pbar | 1 | 1 | Request the specific missing physical input from the researcher; do not fill it with a benchmark. |

- signal, candidate, `O1v@10` (pending): a relativistic completion (a mediator model with couplings to Standard Model particles), from which ⟨σv⟩ today and its final states follow
| 3 | missing_input | planck-2018-omega | 1 | 1 | Request the specific missing physical input from the researcher; do not fill it with a benchmark. |

- signal, candidate, `O1v@10` (pending): a relativistic completion (a mediator model with couplings to Standard Model particles), from which the annihilation cross-sections follow
| 4 | missing_input | cms-2405.13778-V2 | 1 | 1 | Request the specific missing physical input from the researcher; do not fill it with a benchmark. |

- signal, candidate, `O1v@10` (pending): a relativistic completion (a mediator model with couplings to Standard Model particles), from which the mediator's production and decays follow
| 5 | missing_input | atlas-1903.06248-dilepton | 1 | 1 | Request the specific missing physical input from the researcher; do not fill it with a benchmark. |

- signal, candidate, `O1v@10` (pending): a relativistic completion (a mediator model with couplings to Standard Model particles), from which the mediator's production and decays follow
| 6 | missing_input | hess-2608.07234-lines | 1 | 1 | Request the specific missing physical input from the researcher; do not fill it with a benchmark. |

- signal, candidate, `O1v@10` (pending): a relativistic completion (a mediator model with couplings to Standard Model particles), from which ⟨σv⟩ today and its final states follow
| 7 | missing_input | lep-hep-ex-0509008-zinv | 1 | 1 | Request the specific missing physical input from the researcher; do not fill it with a benchmark. |

- signal, candidate, `O1v@10` (pending): a relativistic completion (a mediator model with couplings to Standard Model particles), from which the mediator's production and decays follow
| 8 | missing_input | fermi-lat-1506.00013-lines | 1 | 1 | Request the specific missing physical input from the researcher; do not fill it with a benchmark. |

- signal, candidate, `O1v@10` (pending): a relativistic completion (a mediator model with couplings to Standard Model particles), from which ⟨σv⟩ today and its final states follow
| 9 | missing_input | lmu-ltau-babar-belle2 | 1 | 1 | Request the specific missing physical input from the researcher; do not fill it with a benchmark. |

- signal, candidate, `O1v@10` (pending): a relativistic completion (a mediator model with couplings to Standard Model particles), from which the mediator's production and decays follow
| 10 | missing_input | lep-contact-bl | 1 | 1 | Request the specific missing physical input from the researcher; do not fill it with a benchmark. |

- signal, candidate, `O1v@10` (pending): a relativistic completion (a mediator model with couplings to Standard Model particles), from which the mediator's production and decays follow
| 11 | missing_input | hess-1805.05741-lines | 1 | 1 | Request the specific missing physical input from the researcher; do not fill it with a benchmark. |

- signal, candidate, `O1v@10` (pending): a relativistic completion (a mediator model with couplings to Standard Model particles), from which ⟨σv⟩ today and its final states follow
| 12 | missing_input | atlas-2111.08372-monoz | 1 | 1 | Request the specific missing physical input from the researcher; do not fill it with a benchmark. |

- signal, candidate, `O1v@10` (pending): a relativistic completion (a mediator model with couplings to Standard Model particles), from which the mediator's production and decays follow
| 13 | missing_input | smodels-3.2.1 | 1 | 1 | Request the specific missing physical input from the researcher; do not fill it with a benchmark. |

- signal, candidate, `O1v@10` (pending): a relativistic completion (a mediator model with couplings to Standard Model particles), from which the mediator's production and decays follow
| 14 | missing_input | atlas-2306.00641-2hdma | 1 | 1 | Request the specific missing physical input from the researcher; do not fill it with a benchmark. |

- signal, candidate, `O1v@10` (pending): a relativistic completion (a mediator model with couplings to Standard Model particles), from which the mediator's production and decays follow
| 15 | missing_input | cms-2405.13778-V1 | 1 | 1 | Request the specific missing physical input from the researcher; do not fill it with a benchmark. |

- signal, candidate, `O1v@10` (pending): a relativistic completion (a mediator model with couplings to Standard Model particles), from which the mediator's production and decays follow
| 16 | missing_input | atlas-2301.10731-hinv | 1 | 1 | Request the specific missing physical input from the researcher; do not fill it with a benchmark. |

- signal, candidate, `O1v@10` (pending): a relativistic completion (a mediator model with couplings to Standard Model particles), from which the mediator's production and decays follow
| 17 | missing_input | atlas-1910.08447-dijet-gaussian | 1 | 1 | Request the specific missing physical input from the researcher; do not fill it with a benchmark. |

- signal, candidate, `O1v@10` (pending): a relativistic completion (a mediator model with couplings to Standard Model particles), from which the mediator's production and decays follow
| 18 | missing_input | cms-2405.13778-A2 | 1 | 1 | Request the specific missing physical input from the researcher; do not fill it with a benchmark. |

- signal, candidate, `O1v@10` (pending): a relativistic completion (a mediator model with couplings to Standard Model particles), from which the mediator's production and decays follow
| 19 | missing_input | fermi-2311.04982-spectral | 1 | 1 | Request the specific missing physical input from the researcher; do not fill it with a benchmark. |

- signal, candidate, `O1v@10` (pending): a relativistic completion (a mediator model with couplings to Standard Model particles), from which ⟨σv⟩ today and its final states follow
| 20 | missing_input | fermi-1503.02641-dsph | 1 | 1 | Request the specific missing physical input from the researcher; do not fill it with a benchmark. |

- signal, candidate, `O1v@10` (pending): a relativistic completion (a mediator model with couplings to Standard Model particles), from which ⟨σv⟩ today and its final states follow
| 21 | missing_input | atlas-2108.13391-monoh | 1 | 1 | Request the specific missing physical input from the researcher; do not fill it with a benchmark. |

- signal, candidate, `O1v@10` (pending): a relativistic completion (a mediator model with couplings to Standard Model particles), from which the mediator's production and decays follow
| 22 | missing_input | atlas-2009.14791-zz | 1 | 1 | Request the specific missing physical input from the researcher; do not fill it with a benchmark. |

- signal, candidate, `O1v@10` (pending): a relativistic completion (a mediator model with couplings to Standard Model particles), from which the mediator's production and decays follow
| 23 | missing_input | lep-inert-doublet | 1 | 1 | Request the specific missing physical input from the researcher; do not fill it with a benchmark. |

- signal, candidate, `O1v@10` (pending): a relativistic completion (a mediator model with couplings to Standard Model particles), from which the mediator's production and decays follow
| 24 | missing_input | cms-2405.13778-A1 | 1 | 1 | Request the specific missing physical input from the researcher; do not fill it with a benchmark. |

- signal, candidate, `O1v@10` (pending): a relativistic completion (a mediator model with couplings to Standard Model particles), from which the mediator's production and decays follow
| 25 | missing_input | cms-1806.00843-dijet | 1 | 1 | Request the specific missing physical input from the researcher; do not fill it with a benchmark. |

- signal, candidate, `O1v@10` (pending): a relativistic completion (a mediator model with couplings to Standard Model particles), from which the mediator's production and decays follow
| 26 | missing_input | atlas-2010.14293-squark | 1 | 1 | Request the specific missing physical input from the researcher; do not fill it with a benchmark. |

- signal, candidate, `O1v@10` (pending): a relativistic completion (a mediator model with couplings to Standard Model particles), from which the mediator's production and decays follow
| 27 | missing_input | cms-2107.13021-monojet-spin0 | 1 | 1 | Request the specific missing physical input from the researcher; do not fill it with a benchmark. |

- signal, candidate, `O1v@10` (pending): a relativistic completion (a mediator model with couplings to Standard Model particles), from which the mediator's production and decays follow
| 28 | missing_input | atlas-2207.00092-higgs-mu | 1 | 1 | Request the specific missing physical input from the researcher; do not fill it with a benchmark. |

- signal, candidate, `O1v@10` (pending): a relativistic completion (a mediator model with couplings to Standard Model particles), from which the mediator's production and decays follow
| 29 | missing_input | cms-1908.01115-ttbar | 1 | 1 | Request the specific missing physical input from the researcher; do not fill it with a benchmark. |

- signal, candidate, `O1v@10` (pending): a relativistic completion (a mediator model with couplings to Standard Model particles), from which the mediator's production and decays follow
| 30 | unresolved_calculation | planck-2018-pann | 1 | 1 | Inspect the exact saved reason and complete the bounded deterministic calculation or document the remaining limitation. |

- signal, candidate, `O1v@10` (pending): a calculator for cosmology constraints
| 31 | unresolved_calculation | ccfr-1406.2332-trident | 1 | 1 | Inspect the exact saved reason and complete the bounded deterministic calculation or document the remaining limitation. |

- signal, candidate, `O1v@10` (pending): a calculator for beam_dump constraints
| 32 | unresolved_calculation | ibe-1912.12152-dark-photon-neff | 1 | 1 | Inspect the exact saved reason and complete the bounded deterministic calculation or document the remaining limitation. |

- signal, candidate, `O1v@10` (pending): a calculator for cosmology constraints
| 33 | unresolved_calculation | muon-g2-2025 | 1 | 1 | Inspect the exact saved reason and complete the bounded deterministic calculation or document the remaining limitation. |

- signal, candidate, `O1v@10` (pending): a calculator for flavour constraints
| 34 | unresolved_calculation | sabti-1910.01649-bbn | 1 | 1 | Inspect the exact saved reason and complete the bounded deterministic calculation or document the remaining limitation. |

- signal, candidate, `O1v@10` (pending): a calculator for cosmology constraints
| 35 | unresolved_calculation | darkcast-dark-photon | 1 | 1 | Inspect the exact saved reason and complete the bounded deterministic calculation or document the remaining limitation. |

- signal, candidate, `O1v@10` (pending): a calculator for beam_dump constraints
| 36 | unresolved_calculation | flavour-b-to-k-invisible | 1 | 1 | Inspect the exact saved reason and complete the bounded deterministic calculation or document the remaining limitation. |

- signal, candidate, `O1v@10` (pending): a calculator for flavour constraints
| 37 | unresolved_calculation | icecube-1612.05949-sd | 1 | 1 | Inspect the exact saved reason and complete the bounded deterministic calculation or document the remaining limitation. |

- signal, candidate, `O1v@10` (pending): a telescope limit at 10 GeV; IceCube 2011–2014: dark matter annihilating in the Sun (SD, proton) starts at 35 GeV for bb
| 38 | unresolved_calculation | icecube-1612.05949-si | 1 | 1 | Inspect the exact saved reason and complete the bounded deterministic calculation or document the remaining limitation. |

- signal, candidate, `O1v@10` (pending): a telescope limit at 10 GeV; IceCube 2011–2014: dark matter annihilating in the Sun (SI, proton) starts at 35 GeV for bb

- signal: legacy_unknown provenance; original source review is not inferred
