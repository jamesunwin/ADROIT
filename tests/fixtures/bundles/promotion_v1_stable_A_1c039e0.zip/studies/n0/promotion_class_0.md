# Promotion of O1v@10

<!-- adroit-chronology -->
Report generated (UTC): 2026-11-01T19:47:59.318118+00:00
Calculation started (UTC): 2026-11-01T19:47:59.302065+00:00
Calculation completed (UTC): 2026-11-01T19:47:59.305912+00:00
Conclusions apply to the recorded inputs and calculation date; later data or revisions require a new analysis.
<!-- /adroit-chronology -->

Parent: `parent`; no settled or reserved dollars recorded.

Promoted from the parent's result as read: SHA-256 `a330054e6641ef675b179a7cbe3685e28f1803f0475f7c8f0884b5dee93e07e4`.

| candidate | model | origin | verdict | study |
|---|---|---|---|---|

Without a study:

- O1v@10: isovector: no computable simplified completion produces it at tree level; the model builder can propose isovector completions

<!-- adroit-binding {"figures": {}, "result_sha256": "d96395beb25a6087b9f393eea8af4732a300057cded3e04f59c53f9b9317043b"} -->
